package com.example.order;
import jakarta.persistence.*;
@Entity @Table(name="customer_orders") public class Order {
 @Id public String id; public String sku; public int quantity; public String status;
 protected Order() {} public Order(String id,String sku,int quantity) {this.id=id;this.sku=sku;this.quantity=quantity;this.status="PENDING";}
}
