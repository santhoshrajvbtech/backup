package com.example.order;
import com.fasterxml.jackson.databind.*;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
@Component public class OrderEvents {
 private final OrderRepository repo; private final ObjectMapper json;
 OrderEvents(OrderRepository r,ObjectMapper j){repo=r;json=j;}
 @KafkaListener(topics={"inventory.reserved","inventory.rejected"},groupId="order-service")
 @Transactional public void handle(String payload) throws Exception {
  JsonNode n=json.readTree(payload);String id=n.get("orderId").asText();String status=n.get("status").asText();
  repo.findById(id).ifPresent(o->{if("PENDING".equals(o.status)){o.status=status;repo.save(o);}});
 }
}
