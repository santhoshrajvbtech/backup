package com.example.inventory;
import jakarta.persistence.*;
@Entity @Table(name="processed_inventory_orders") public class ProcessedOrder {
 @Id public String orderId; public String status;
 protected ProcessedOrder(){} public ProcessedOrder(String id,String status){this.orderId=id;this.status=status;}
}
