package com.example.inventory;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/stock") @CrossOrigin(origins="*") public class InventoryController {
 private final StockRepository repo;InventoryController(StockRepository r){repo=r;}
 @GetMapping public List<Stock> all(){return repo.findAll();}
}
