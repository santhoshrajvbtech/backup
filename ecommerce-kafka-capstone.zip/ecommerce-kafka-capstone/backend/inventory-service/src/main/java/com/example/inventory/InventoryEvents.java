package com.example.inventory;
import com.fasterxml.jackson.databind.*;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import java.util.Map;
@Component public class InventoryEvents {
 private final StockRepository stock;private final ProcessedRepository processed;private final KafkaTemplate<String,String> kafka;private final ObjectMapper json;
 InventoryEvents(StockRepository s,ProcessedRepository p,KafkaTemplate<String,String> k,ObjectMapper j){stock=s;processed=p;kafka=k;json=j;}
 @Bean CommandLineRunner seed(){return args->stock.save(stock.findById("SKU-1").orElseGet(()->new Stock("SKU-1",100)));}
 @KafkaListener(topics="order.created",groupId="inventory-service")
 @Transactional public void reserve(String payload) throws Exception {
  JsonNode n=json.readTree(payload);String id=n.get("orderId").asText(),sku=n.get("sku").asText();int qty=n.get("quantity").asInt();
  String status;
  if(processed.existsById(id)){status=processed.findById(id).orElseThrow().status;}
  else {
   Stock s=stock.lockBySku(sku).orElse(null);
   if(s!=null && s.available>=qty){s.available-=qty;stock.save(s);status="CONFIRMED";}else{status="REJECTED";}
   processed.save(new ProcessedOrder(id,status));
  }
  String topic="CONFIRMED".equals(status)?"inventory.reserved":"inventory.rejected";
  kafka.send(topic,id,json.writeValueAsString(Map.of("orderId",id,"status",status)));
 }
}
