package com.example.inventory;
import jakarta.persistence.*;
@Entity @Table(name="stock") public class Stock {
 @Id public String sku; public int available;
 protected Stock(){} public Stock(String sku,int available){this.sku=sku;this.available=available;}
}
