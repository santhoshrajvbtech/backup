package com.example.inventory;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ProcessedRepository extends JpaRepository<ProcessedOrder,String> {}
