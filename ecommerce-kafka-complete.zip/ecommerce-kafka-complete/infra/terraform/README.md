# Terraform cloud-agnostic deployment plan
Use a cloud-specific provider module (AWS EKS, Azure AKS, or GCP GKE), with a common Kubernetes/Helm application layer.
This folder is a design placeholder, not deployable infrastructure. Configure state, VPC/VNet, managed database, secrets, ingress and IAM before production.
