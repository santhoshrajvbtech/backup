import React,{useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';import './style.css';
type Order={id:string;sku:string;quantity:number;status:string};
type Product={id:string;name:string;sku:string;price:number};
function App(){
 const [tab,setTab]=useState<'store'|'seller'|'admin'>('store');const [orders,setOrders]=useState<Order[]>([]);const [products,setProducts]=useState<Product[]>([]);
 const [sku,setSku]=useState('SKU-1'),[quantity,setQuantity]=useState(1),[name,setName]=useState(''),[price,setPrice]=useState(10),[error,setError]=useState('');
 async function refresh(){try{const [o,pr]=await Promise.all([fetch('/api/orders'),fetch('/api/products')]);if(o.ok)setOrders(await o.json());if(pr.ok)setProducts(await pr.json());}catch(e){setError(String(e))}}
 useEffect(()=>{void refresh();const timer=setInterval(()=>void refresh(),4000);return()=>clearInterval(timer)},[]);
 async function createOrder(){setError('');try{const r=await fetch('/api/orders',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sku,quantity})});if(!r.ok)throw Error(await r.text());await refresh()}catch(e){setError(String(e))}}
 async function createProduct(){setError('');try{const r=await fetch('/api/products',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,sku,price,stockKeepingUnit:sku})});if(!r.ok)throw Error(await r.text());await refresh()}catch(e){setError(String(e))}}
 return <main><header><span className="logo">◈</span><strong>CloudCart</strong><span className="tag">Kafka microservices capstone</span></header>
 <nav style={{display:'flex',gap:12,margin:'20px 0'}}>{(['store','seller','admin'] as const).map(t=><button key={t} className={tab===t?'':'secondary'} onClick={()=>setTab(t)}>{t.toUpperCase()}</button>)}</nav>
 <section className="hero"><div><p className="eyebrow">JAVA 21 · REACT · KAFKA · KUBERNETES</p><h1>{tab==='store'?'Customer Storefront':tab==='seller'?'Seller Portal':'Admin Dashboard'}</h1><p>Event-driven order processing with Spring Boot and PostgreSQL</p></div><span className="live">● Demo</span></section>
 {error&&<p className="error">{error}</p>}
 {tab==='store'&&<div className="columns"><section className="panel"><h2>Place an order</h2><label>SKU</label><input value={sku} onChange={e=>setSku(e.target.value)}/><label>Quantity</label><input type="number" min="1" value={quantity} onChange={e=>setQuantity(Math.max(1,+e.target.value))}/><button onClick={createOrder}>Place order</button><p className="muted">SKU-1 has 100 units of seeded inventory.</p></section><section className="panel"><h2>Products</h2>{products.map(p=><p key={p.id}>{p.name} · {p.sku} · {p.price}</p>)}{!products.length&&<p className="muted">Add products in Seller Portal.</p>}</section></div>}
 {tab==='seller'&&<section className="panel"><h2>Register product</h2><label>Name</label><input value={name} onChange={e=>setName(e.target.value)}/><label>SKU</label><input value={sku} onChange={e=>setSku(e.target.value)}/><label>Price</label><input type="number" value={price} onChange={e=>setPrice(+e.target.value)}/><button onClick={createProduct}>Create product</button></section>}
 {tab==='admin'&&<section className="panel"><h2>Order dashboard</h2><p>Total orders: {orders.length} · Confirmed: {orders.filter(o=>o.status==='CONFIRMED').length}</p><button className="secondary" onClick={refresh}>Refresh</button></section>}
 <section className="panel" style={{marginTop:24}}><h2>Kafka order lifecycle</h2><div className="tablewrap"><table><thead><tr><th>Order</th><th>SKU</th><th>Quantity</th><th>Status</th></tr></thead><tbody>{orders.slice().reverse().map(o=><tr key={o.id}><td>{o.id.slice(0,8)}</td><td>{o.sku}</td><td>{o.quantity}</td><td><span className={'status '+o.status.toLowerCase()}>{o.status}</span></td></tr>)}</tbody></table></div></section>
 <footer>Order → transactional outbox → Kafka → Inventory → Kafka → Order status</footer></main>
}createRoot(document.getElementById('root')!).render(<App/>);
