package com.example.product;
public interface ProductRepository extends org.springframework.data.jpa.repository.JpaRepository<Product,String>{}
