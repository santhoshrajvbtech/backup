package com.example.product;
@jakarta.persistence.Entity public class Product {@jakarta.persistence.Id public String id; public String name; public String sku; public java.math.BigDecimal price; public String stockKeepingUnit; public Product(){}}
