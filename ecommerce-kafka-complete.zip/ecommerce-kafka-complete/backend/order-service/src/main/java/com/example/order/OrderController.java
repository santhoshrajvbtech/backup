package com.example.order;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.transaction.support.TransactionTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.util.*;
@RestController @RequestMapping("/api/orders") @CrossOrigin(origins="*") public class OrderController {
 record CreateOrder(@NotBlank String sku,@Min(1) int quantity) {}
 private final OrderRepository repository; private final OutboxRepository outbox; private final ObjectMapper json; private final TransactionTemplate tx;
 OrderController(OrderRepository r,OutboxRepository b,ObjectMapper j,TransactionTemplate t){repository=r;outbox=b;json=j;tx=t;}
 @PostMapping public ResponseEntity<Order> create(@Valid @RequestBody CreateOrder req) throws Exception {
  Order order=new Order(UUID.randomUUID().toString(),req.sku(),req.quantity());
  String event=json.writeValueAsString(Map.of("orderId",order.id,"sku",order.sku,"quantity",order.quantity));
  tx.executeWithoutResult(s->{repository.save(order);outbox.save(new OutboxEvent(UUID.randomUUID().toString(),"order.created",order.id,event));});
  return ResponseEntity.status(HttpStatus.CREATED).body(order);
 }
 @GetMapping("/{id}") public Order get(@PathVariable String id){return repository.findById(id).orElseThrow(()->new org.springframework.web.server.ResponseStatusException(HttpStatus.NOT_FOUND));}
 @GetMapping public List<Order> all(){return repository.findAll();}
}
