package com.example.order;
import org.springframework.data.jpa.repository.*;import org.springframework.data.repository.query.Param;import jakarta.persistence.LockModeType;import java.util.*;
public interface OutboxRepository extends JpaRepository<OutboxEvent,String>{
 @Lock(LockModeType.PESSIMISTIC_WRITE) @Query("select e from OutboxEvent e where e.published=false order by e.id") List<OutboxEvent> pending();
}
