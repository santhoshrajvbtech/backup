package com.example.order;
import org.springframework.stereotype.Component;import org.springframework.scheduling.annotation.Scheduled;import org.springframework.transaction.annotation.Transactional;
import org.springframework.kafka.core.KafkaTemplate;import java.util.concurrent.TimeUnit;
@Component public class OutboxPublisher {
 private final OutboxRepository repository;private final KafkaTemplate<String,String> kafka;
 OutboxPublisher(OutboxRepository r,KafkaTemplate<String,String> k){repository=r;kafka=k;}
 @Scheduled(fixedDelayString="${outbox.poll-ms:1000}") @Transactional
 public void publish(){for(var event:repository.pending()){
  try {kafka.send(event.topic,event.aggregateId,event.payload).get(10,TimeUnit.SECONDS);event.published=true;repository.save(event);}
  catch(Exception e){break;}
 }}
}
