package com.example.order;
import jakarta.persistence.*;
@Entity @Table(name="order_outbox") public class OutboxEvent {
 @Id public String id; @Column(nullable=false) public String topic; @Column(nullable=false) public String aggregateId;
 @Column(nullable=false,length=8000) public String payload; public boolean published;
 protected OutboxEvent(){} public OutboxEvent(String id,String topic,String aggregateId,String payload){this.id=id;this.topic=topic;this.aggregateId=aggregateId;this.payload=payload;}
}
