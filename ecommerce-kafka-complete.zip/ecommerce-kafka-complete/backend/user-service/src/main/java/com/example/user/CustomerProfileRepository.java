package com.example.user;
public interface CustomerProfileRepository extends org.springframework.data.jpa.repository.JpaRepository<CustomerProfile,String>{}
