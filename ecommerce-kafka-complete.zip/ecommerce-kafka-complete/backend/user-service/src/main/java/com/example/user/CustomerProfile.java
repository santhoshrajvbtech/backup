package com.example.user;
@jakarta.persistence.Entity public class CustomerProfile {@jakarta.persistence.Id public String id; public String displayName; public String email; public String phone; public String address; public CustomerProfile(){}}
