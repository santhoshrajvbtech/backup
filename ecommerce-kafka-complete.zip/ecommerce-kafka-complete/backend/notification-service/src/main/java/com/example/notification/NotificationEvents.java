package com.example.notification;
@org.springframework.stereotype.Component public class NotificationEvents {
 private static final org.slf4j.Logger log=org.slf4j.LoggerFactory.getLogger(NotificationEvents.class);
 @org.springframework.kafka.annotation.KafkaListener(topics={"inventory.reserved","inventory.rejected"},groupId="notification-service")
 public void notifyCustomer(String message){log.info("Notification event received: {}",message);}
}
