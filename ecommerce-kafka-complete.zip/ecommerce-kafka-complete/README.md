# CloudCart: Java Full Stack + Kafka capstone

A multi-service **learning project**, not a fully finished production application. See [milestone status](docs/MILESTONES.md).

## Stack
Java 21, Spring Boot 3.3.13, PostgreSQL, Kafka, React/TypeScript, Docker Compose, Redis, Keycloak, Prometheus/Grafana, Kubernetes manifests, GitHub Actions.

## Local startup
```bash
docker compose up --build
```

| Component | URL |
|---|---|
| React storefront / seller / admin demo | http://localhost:5173 |
| Order API | http://localhost:8081/api/orders |
| Inventory API | http://localhost:8082/api/stock |
| Product API | http://localhost:8083/api/products |
| User API | http://localhost:8084/api/users |
| Keycloak (unconfigured) | http://localhost:8180 |
| Prometheus | http://localhost:9090 |
| Grafana | http://localhost:3000 |

## Kafka test
```bash
curl -X POST http://localhost:8081/api/orders -H 'Content-Type: application/json' -d '{"sku":"SKU-1","quantity":2}'
curl http://localhost:8081/api/orders
```

Flow: Order persisted + outbox row in same transaction → publisher sends `order.created` → inventory reserves stock → `inventory.reserved` or `inventory.rejected` → order status updated → notification service logs event.

## Important limitations
The code has not been built or end-to-end tested in this environment. The React pages are demonstration screens, not secured customer/seller/admin portals. Keycloak is running but not wired into Spring Security or React. Kubernetes manifests require image registry, configuration and dependent infrastructure. Review [MILESTONES.md](docs/MILESTONES.md) before treating any milestone as complete.
